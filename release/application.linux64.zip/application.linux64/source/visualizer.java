import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.spi.*; 
import ddf.minim.signals.*; 
import ddf.minim.*; 
import ddf.minim.analysis.*; 
import ddf.minim.ugens.*; 
import ddf.minim.effects.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class visualizer extends PApplet {








int DEF_WIDTH = 1280;
int DEF_HEIGHT = 720;

Table table;
int i = 0;
int rowCount;
int frameN = 0;
int fpe;
float radius;
float scale;
float att;
float outerRadius;
float innerRadius;

Minim minim;
AudioPlayer song;

public float att() {
  return table.getRow(i).getFloat("EEGATT"); 
}

public float lastAtt() {
  if (i > 0) {
    return table.getRow(i-1).getFloat("EEGATT");
  } else {
    return 0.0f;
  }
}

public boolean hasMore() {
  return i < rowCount-1;
}

public void next() {
  if (hasMore()) {
    if (frameN == fpe) {
      i++;
      frameN = 0;
    } else {
      frameN++;
    }    
  } else {
    i = 0;    
  }
} 

public float getScale() {
  if (height > width) {
    return width / 100;
  } else {
    return height / 100;
  }
}

public void setupViewPort() {
  size(DEF_WIDTH, DEF_HEIGHT);
  if (frame != null) {
    frame.setResizable(true);
  }
  
  fpe = 15;
  frameRate(fpe * 2);
}

public void setupMinim() {
  minim = new Minim(this);
  song = minim.loadFile("data/session.mp3");
  song.play();
}

public void setupTable() {
  table = loadTable("data/attention.csv", "header");  
  rowCount = table.getRowCount();  

  println(rowCount + " total rows in table");
}

public void setup() {
  setupViewPort();
  setupMinim();
  setupTable(); 
}

public void calculateFrame() {
  scale = getScale() / 2;
  att = lastAtt() + (att() - lastAtt()) / fpe * frameN;
  innerRadius = att * scale;
}

public void drawCircleWave() {
  int buffSize = song.bufferSize();
  float step = TWO_PI / (buffSize - 1);
  float start = 0;
  float end = step;
  float left;
  float right;
  float arcRadius;
  
  for(int i = 0; i < buffSize - 1; i++) {
      left = innerRadius / 20 + song.left.get(i) * scale * 100;
      right = innerRadius / 20 + left + song.right.get(i) * scale * 100;
    
      fill(64);
      arc(width/2, height/2, innerRadius + left, innerRadius + left, start, end);
      fill(127);
      arc(width/2, height/2, innerRadius + right, innerRadius + right, start, end);
      start = end;
      end += step;
  }
}

public void drawCircles() {
  noStroke();
  drawCircleWave();
  fill(255);
  ellipse(width/2, height/2, innerRadius, innerRadius);
}

public void draw() {
  calculateFrame();
  
  background(65);
  noStroke();
  
  drawCircles();

  next();
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "visualizer" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
